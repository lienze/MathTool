from distutils.core import setup

setup(
    name='PyMathTool',
    version='0.0.1',
    packages=["PyMathTool/LinearAlgebra"],
    author='lienze',
    author_email='lienze@126.com'
)

