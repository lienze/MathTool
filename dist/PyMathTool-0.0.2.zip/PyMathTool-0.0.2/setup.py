from distutils.core import setup

setup(
    name='PyMathTool',
    version='0.0.2',
    packages=['PyMathTool/LinearAlgebra/',
              'PyMathTool/AdvancedMath/'],
    author='lienze',
    author_email='lienze@126.com',
    License='GNU General Public License V2.0'
)

